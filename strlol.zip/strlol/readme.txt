Use 'sudo apt-get install <name>' to install the following required packages:
libsdl2-2.0-0
libsdl2-image-2.0-0
