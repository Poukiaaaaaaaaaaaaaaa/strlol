#include <iostream>
#include <string>

#include <SDL2/SDL.h>
#include <IMG/SDL_image.h>
#undef _main

using namespace std;

char verf[] = {
	'a', 'b', 'c', 'd', 'e', 'f', 'g',
	'h', 'i', 'j', 'k', 'l', 'm', 'n',
	'o', 'p', 'q', 'r', 's', 't', 'u',
	'v', 'w', 'x', 'y', 'z', ' '
};

#define CHAR_COUNT 27
#define IMG_SIDE 200

int main(int argc, char * argv[])
{
	cout << "Input: ";
	string s; getline(cin, s);
	string tmpstr;

	for (unsigned i = 0; i < s.length(); i++)
	{
		for (unsigned j = 0; j < CHAR_COUNT; j++)
		{
			if (s[i] == verf[j])
				break;

			if (s[i] != verf[j] && j == CHAR_COUNT - 1)
			{
				cout << "Incorrect string, unexpected character: " << s[i] << '\n';
				return EXIT_FAILURE;
			}
		}
	}

	for (unsigned i = 0; i < s.length(); i++)
	{
		if (i) cout << "Processing " << (int)((float)i / s.length() * 100) << "%\n";

		char t = tolower(s[i]); tmpstr = t;
		s.replace(i, 1, tmpstr);

		SDL_Init(SDL_INIT_VIDEO);

		SDL_Surface * tmp;
		SDL_Surface * final = SDL_CreateRGBSurface(
			0, s.length() * IMG_SIDE, IMG_SIDE, 32, 0, 0, 0, 0
		);

		for (unsigned i = 0; i < s.length(); i++)
		{
			if (s[i] == ' ') continue;

			tmpstr = "Alphabet/";
			string path = tmpstr + s[i] + ".png";
			tmp = IMG_Load(path.c_str());

			SDL_Rect pos = {
				i * IMG_SIDE,
				0, NULL, NULL
			};

			SDL_BlitSurface(tmp, NULL, final, &pos);
		}

		IMG_SavePNG(final, "out.png");

		SDL_FreeSurface(tmp);
		SDL_FreeSurface(final);
		SDL_Quit();
	}

	return EXIT_SUCCESS;
}
