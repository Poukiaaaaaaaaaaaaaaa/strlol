g++ -o strlol strlol.cpp -lSDL2main -lSDL2 -lSDL2_image
